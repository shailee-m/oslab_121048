echo "enter file name"
read fn
cat $fn | wc -w
