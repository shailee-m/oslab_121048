echo "Enter filename with extension"
read fn
cat $fn | tr -d '\n' | tr -s " " '\n' | wc -l
