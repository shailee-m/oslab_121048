choice=1;
while [ $choice -eq 1 ]
do
echo "enter basic salary";
read b;
if [ "$b" -gt "0" ] 
then
choice=0
else
echo "enter valid number"
fi

done
#HRA=0.12;
#hra= $((b*HRA));
echo "0.12 * $b" | bc
#echo "Your HRA is $hra";
