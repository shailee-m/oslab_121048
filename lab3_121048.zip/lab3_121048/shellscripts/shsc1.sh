#!/bin/bash
echo "enter a";
read a;
echo "enter b";

read b;
echo "sum";
sum=$((a+b));
echo "$sum";
echo "difference";
d=$((a-b));
echo "$d";
echo "multiplication";
m=$((a*b));
echo "$m";

echo "division";
div=$((a/b));
echo "$div";
echo "modulo";
mo=$((a%b));
echo "$mo";
#echo `expr $a + $b`;
