#!/bin/bash
echo "Enter at least 3 initials for January month:";
read m
case $m in
Jan) echo "month=January ";;
Janu) echo "month=January" ;;
Janua) echo "month=January" ;;
January) echo "month=January" ;;
Januar) echo "month=January" ;;
jan) echo "month=January" ;;
janu) echo "month=January" ;;
janua) echo "month=January" ;;
januar) echo "month=January" ;;
january) echo "month=January" ;;



*)   echo "enter valid month";;  
esac




