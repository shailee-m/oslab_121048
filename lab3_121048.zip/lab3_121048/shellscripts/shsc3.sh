#!/bin/bash
echo "enter a";
read a;
echo "enter b";

read b;

echo "enter 1 for addition 2 for subtraction 3 for mul. 4 for division and 5 for modulo";
read choice;
case "$choice" in
  1)
    echo "sum";
sum=$((a+b));
echo "$sum";;
  2)
   echo "difference";
d=$((a-b));
echo "$d";;
    
  3) echo "multiplication";
m=$((a*b));
echo "$m";;
  
  4)
  echo "division";
div=$((a/b));
echo "$div";;
5) 
echo "modulo";
mo=$((a%b));
echo "$mo";
esac






