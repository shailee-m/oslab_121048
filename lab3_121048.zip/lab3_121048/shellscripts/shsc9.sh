#!/bin/bash


c=1
while test $c -ne 0
do
echo "What is the capital of Gujarat?"

read ans
if test "Gandhinagar" = "$ans"
then
c=0
echo "that's true"

elif test "gandhinagar" = "$ans"
then
c=0
echo "that's true"
else
c=1
fi

done
