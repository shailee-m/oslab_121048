#!/bin/bash
echo "enter command: "
read c
$c
