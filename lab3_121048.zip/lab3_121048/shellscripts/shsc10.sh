#!/bin/bash

echo "create  list";
c=1;
cnt=0;
while test $c -ne 0
do
echo "Enter numbers"
read num[$cnt]
cnt=`expr $cnt + 1`

echo "Press 1 to continue , 0 to exit"
read c
done

echo "the number to be found"
read a

cnts=0;
count=0;

for cnts in `seq 0 $cnt`
do
if test ${num[$cnts]} == $a
then
count=$count+1
echo "$a is at $cnts th position"
fi
cnts=`expr $cnts + 1`
done
echo "total entries "
echo $count


