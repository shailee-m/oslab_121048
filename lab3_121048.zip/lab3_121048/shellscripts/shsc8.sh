#!/bin/bash

echo "enter first num of the series"
read a;
echo "enter 2nd num of the series"
read b;

echo "enter the length of the series"
read n;
m=$(($n +1))
count=1;
while test $count -ne $m
do
c=$((a+b))
echo $c
a=$((b+0))
b=$((c+0))
count=`expr $count + 1`
done
