#!/bin/bash
echo "enter a";
read a;
echo "enter b";

read b;

if test $a -gt $b
then
   echo "$a is greater than $b"
elif test $a -lt $b	
then 
 echo "$a is smaller than $b"
else
  echo "both are equal"
   
fi
