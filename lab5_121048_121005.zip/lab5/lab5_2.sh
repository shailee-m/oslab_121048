echo Enter string
read str
n=` expr $str | rev `
if [ "$str" == "$n" ] 
then
echo "PAlindrome";
else
echo not palindrome 
fi
