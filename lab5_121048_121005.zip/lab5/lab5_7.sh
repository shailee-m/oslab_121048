echo "Enter an alphabet"
read n
ls  $n*
