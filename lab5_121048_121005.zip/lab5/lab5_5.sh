echo "enter first File"
read n
echo "enter next file"
read m
if [ -e $n ]
then
if [ -e $m ]
then
cat $n>>$m
else
cat $n>$m
fi
fi
