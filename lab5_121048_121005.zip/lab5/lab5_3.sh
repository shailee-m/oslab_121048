printf "$1\n%.0s"  $(seq 1 $2)
